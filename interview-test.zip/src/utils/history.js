import createBrowserHistory from 'history/createBrowserHistory';

export default createBrowserHistory({
  basename: '/react-twitter',
});
