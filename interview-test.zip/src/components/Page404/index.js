export { default } from './Page404';
